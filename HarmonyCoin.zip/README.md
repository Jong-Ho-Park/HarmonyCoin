<h1>HarmonyCoin</h1>


| Specification  | Details |
| ------------- | ------------- |
| Protocol  | 100% Proof-of-Stake (PoS)  |
| Block Time  | 1 minutes |
| Block Rewards  | 1 Coin  |
| Stake  | 10% per year depending on difficulty  |
| Stake Weight | 2/14 min/max days |
| Stake Threshold | 10 days |
| Fee | .2 Coin |
| RPC Port  | 14201  |
| P2P Port | 14200 |
| Cryptographic Algorithm  | x13  |
| Difficulty Retarget  | 16 minutes or 8 blocks |
